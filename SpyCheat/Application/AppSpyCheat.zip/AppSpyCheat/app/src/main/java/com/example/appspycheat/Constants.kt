package com.example.appspycheat

import android.Manifest

/*
* Source :
* Aide caméraX (Vidéo Youtube) -> https://www.youtube.com/watch?v=HjXJh_vHXFs
 */
object Constants {
    const val TAG = "cameraX"
    const val REQUEST_CODE_PERMISSION = 123
    val REQUIRED_PERMISSIONS = arrayOf(Manifest.permission.CAMERA)
}